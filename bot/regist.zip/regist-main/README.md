# regist

<pre><code>wget https://raw.githubusercontent.com/LunaticBackend/regist/main/klmpkbot.sh && chmod +x klmpkbot.sh && ./klmpkbot.sh</code></pre>
